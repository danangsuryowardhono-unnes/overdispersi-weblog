# Ringkasan analisis tambahan — Org Y

Menit dianalisis: 26362 (fase I 15817, fase II 10545)

D 1 menit = 139.33; ACF lag 1 = 0.817; lag pertama ACF < 0,1 = None

- IK 95% block bootstrap, blok 30 menit: 114.45–166.69
- IK 95% block bootstrap, blok 60 menit: 110.72–170.21
- IK 95% block bootstrap, blok 120 menit: 106.83–173.40
- Deret dijarangkan 120 menit: n = 220, D = 196.11, p = 0.00e+00

r NB (fase I) = 1.014, IK 95% profil 0.994–1.034; gradien di optimum -3.34e-04

NB + lag: β1 = 0.878 (SE 0.005), β2 = 0.091 (SE 0.005), r = 6.14
INGARCH(1,1)-NB: a = 0.990, b = 0.000, r = 5.98

Log-score fase II per observasi:
- Poisson homogen: -22.046
- NHPP per jam: -22.965
- Binomial negatif: -5.466
- NB + lag: -4.798
- INGARCH(1,1)-NB: -4.820

Rolling-origin (rata-rata LS):
- Poisson homogen: -20.036
- NHPP per jam: -21.549
- Binomial negatif: -5.472
- NB + lag: -4.780
- INGARCH(1,1)-NB: -4.791
Model terbaik per titik asal: {'NB + lag': 3, 'INGARCH(1,1)-NB': 1}

Diagnostik residual (fase II):
- Binomial negatif: ACF lag1 = 0.601, Ljung–Box(60) p = 0.00e+00
- NB + lag: ACF lag1 = -0.072, Ljung–Box(60) p = 4.35e-08
- INGARCH(1,1)-NB: ACF lag1 = -0.095, Ljung–Box(60) p = 1.58e-13

Ringkasan uji per jam (Bonferroni α = 0,05/24):
- akhir pekan, 1 menit: tolak 24/24, overdispersi 24/24, median D 163.3
- akhir pekan, 5 menit: tolak 24/24, overdispersi 24/24, median D 675.2
- akhir pekan, 10 menit: tolak 1/24, overdispersi 24/24, median D 1241.3
- hari kerja, 1 menit: tolak 24/24, overdispersi 24/24, median D 81.9
- hari kerja, 5 menit: tolak 24/24, overdispersi 24/24, median D 280.5
- hari kerja, 10 menit: tolak 24/24, overdispersi 24/24, median D 426.8
- semua, 1 menit: tolak 24/24, overdispersi 24/24, median D 124.4
- semua, 5 menit: tolak 24/24, overdispersi 24/24, median D 500.3
- semua, 10 menit: tolak 24/24, overdispersi 24/24, median D 882.9

Monitoring pada target FAR 0,135%: lihat tabel_B2_monitoring.csv
